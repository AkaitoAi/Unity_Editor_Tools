using DG.Tweening;
using System.Collections.Generic;
using TMPro;
using UIAnimatorCore;
using UnityEngine;
using UnityEngine.UI;

public class TaskUiManager : MonoBehaviour
{
    public static TaskUiManager instance;
    [System.Serializable]
    public class TaskUi
    {
        public string taskId;
        public int taskIndex;
        public GameObject taskParent;
        public Image taskStatusImage;
        public TextMeshProUGUI taskDetailsText;
    }

    [Header("Task Prefab")]
    [SerializeField] private GameObject taskPrefab;
    [SerializeField] private GameObject taskBody;
    [SerializeField] private GameObject taskDropDownArrow;

    [Header("Task Container")]
    [SerializeField] private TextMeshProUGUI taskTitle;
    [SerializeField] private Transform taskContainer;

    [Header("Task")]
    [SerializeField] private Sprite[] taskStatusSprites;
    [SerializeField] private int taskCount;
    [SerializeField] private bool autoHideTask;
    [SerializeField] private float autoHideTaskDelay;
    [SerializeField] private List<TaskUi> tasksUi = new List<TaskUi>();
    private int taskVisibilty;
    private UIAnimator animator;
    private Vector3 taskDropDownArrowScale;

    [SerializeField] private TaskData_Scriptable taskFile;
    [SerializeField] private TaskDetails[] taskDetails;
    [SerializeField] private TaskDetails currentTaskDetails;
    [SerializeField] private TaskDetails currentTaskDetailScriptableRef;
    

    private void Awake()
    {
        instance = this;
        animator = GetComponent<UIAnimator>();
    }

    void OnDisable()
    {
        CancelInvoke("ShowHideTask");
        TaskManager.OnTaskUpdateEvent -= UpdateTaskUI;
    }
    private void OnDestroy()
    {
        CancelInvoke("ShowHideTask");
    }

    public void SetTaskFile(TaskData_Scriptable _taskFile)
    {
        TaskManager.OnTaskUpdateEvent += UpdateTaskUI;
        taskFile = _taskFile;
        taskDetails = taskFile.tasks;

        taskDropDownArrowScale = taskDropDownArrow.transform.localScale;

        if (taskBody.activeInHierarchy) { taskDropDownArrow.transform.DOLocalRotate(new Vector3(180, 0, 0), 0.75f); }
        if (!taskBody.activeInHierarchy) { taskDropDownArrow.transform.DOLocalRotate(new Vector3(0, 0, 0), 0.75f); }
    }
    public void UpdateTaskUI(string TaskId)
    {
        taskDetails = taskFile.tasks;
        foreach (var task_ui in tasksUi)
        {
            if (task_ui.taskId == TaskId)
            {
                foreach (var task_deatil in taskDetails)
                {
                    if (task_deatil.ID == TaskId)
                    {
                        string _string = $"<color=grey>{task_ui.taskIndex}</color>: {task_deatil.TaskTagHeading}: {task_deatil.TaskTriggered}/ {task_deatil.TaskTargetValue}";
                        task_ui.taskDetailsText.text = _string;

                        if (task_deatil.TaskTriggered >= task_deatil.TaskTargetValue)
                        {
                            task_ui.taskStatusImage.sprite = taskStatusSprites[1];
                        }
                    }
                }
            }
        }
    }

    public void GenerateTasksUi()
    {
        taskTitle.text = $"Tasks: {taskDetails.Length}";

        for (int i = 0; i < taskDetails.Length; i++)
        {
            int taskGenerater = 0;
            taskGenerater++;
            GameObject taskObject = Instantiate(taskPrefab, taskContainer);
            TaskUi taskUi = new TaskUi
            {
                taskParent = taskObject,
                taskStatusImage = taskObject.transform.GetChild(0).GetComponent<Image>(),
                taskDetailsText = taskObject.transform.GetChild(1).GetComponent<TextMeshProUGUI>()
            };
            taskUi.taskId = taskDetails[i].ID;
            taskUi.taskIndex = taskCount + 1;
            taskUi.taskDetailsText.text = $"<color=white> {taskDetails[i].Objectives}";
            taskUi.taskStatusImage.sprite = taskStatusSprites[0];

            tasksUi.Add(taskUi);
            taskCount++;
            taskObject.SetActive(true);

        }
    }


    public void ShowHideTask()
    {
        taskVisibilty = (taskVisibilty + 1) % 2;

        if (taskVisibilty == 0)
        {
            animator.PlayAnimation(AnimSetupType.Outro);
            DOTween.Sequence()
            .Append(taskDropDownArrow.transform.DOScale(new Vector3(0f, 0f, 0f), 0.4f))
            .Append(taskDropDownArrow.transform.DOLocalRotate(new Vector3(180, 0, 0), 0.2f))
            .Append(taskDropDownArrow.transform.DOScale(taskDropDownArrowScale, 0.4f));

        }
        if (taskVisibilty == 1)
        {
            animator.PlayAnimation(AnimSetupType.Intro);

            taskDropDownArrow.transform.DOLocalRotate(new Vector3(0, 0, 0), 0.75f);
            DOTween.Sequence()
            .Append(taskDropDownArrow.transform.DOScale(new Vector3(0f, 0f, 0f), 0.4f))
            .Append(taskDropDownArrow.transform.DOLocalRotate(new Vector3(0, 0, 0), 0.2f))
            .Append(taskDropDownArrow.transform.DOScale(taskDropDownArrowScale, 0.4f));
        }
    }
    public void SetAutoHideTask()
    {
        if (autoHideTask) { Invoke(nameof(ShowHideTask), autoHideTaskDelay); }
    }
}


