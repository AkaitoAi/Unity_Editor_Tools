using System;
using UnityEngine;

[Serializable]
public class TaskDetails
{
    public string Name;
    public string ID;
    public string Objectives;
    public string TaskTagHeading;
    public int TaskTargetValue;
    public int TaskTriggered;
    public bool IsCompleted;
}
[CreateAssetMenu(fileName = "TaskData", menuName = "Scriptable Objects/TaskData")]
public class TaskData_Scriptable : ScriptableObject
{
    public TaskDetails[] tasks;


    //private void OnValidate()
    //{
    //    foreach (var task in tasks)
    //    {
    //        if (string.IsNullOrEmpty(task.ID))
    //        {
    //            task.ID = GenerateUniqueID(task.Name);
    //        }
    //    }
    //}

    //private string GenerateUniqueID(string name)
    //{
    //    return $"{name}_{Guid.NewGuid()}";
    //}
}