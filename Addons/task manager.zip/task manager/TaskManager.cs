using System;
using System.Text;
using UnityEngine;

public class TaskManager : MonoBehaviour
{
    public static TaskManager instance;
    [SerializeField] private TaskData_Scriptable taskFile;
    [SerializeField] private TaskDetails[] taskDetails;
    [SerializeField] private TaskDetails currentTaskDetails;
    [SerializeField] private TaskDetails currentTaskDetailScriptableRef;

    private int taskCompletedValue;
    private String taskObjectives;
    private String currentID = "df";
    public event Action OnAllTaskCompleted;
    public static event Action<string> OnTaskUpdateEvent;
    public bool levelCompleted = false;

    private void Awake()
    {
        instance = this;
    }
    public void SetTaskFile(TaskData_Scriptable _taskFile)
    {
        taskFile = _taskFile;
        StringBuilder builder = new StringBuilder(taskObjectives);
        foreach (var task in taskFile.tasks)
        {
            task.TaskTriggered = 0;
            task.IsCompleted = false;

            builder.AppendLine($"> {task.Objectives}");
        }
        taskDetails = taskFile.tasks;
        taskObjectives = builder.ToString();
    }
    public String GetTaskObjectives() { return taskObjectives; }
    TaskDetails GetCurrentTaskTemp(string taskID)
    {
        foreach (var task in taskDetails)
        {
            if (taskID == task.ID) { return task; }
        }
        return null;
    }
    TaskDetails GetCurrentTaskScriptableRef(string taskID)
    {
        foreach (var task in taskFile.tasks)
        {
            if (taskID == task.ID) { return task; }
        }
        return null;
    }
    public void TriggerTask(String taskID)
    {
        currentTaskDetails = GetCurrentTaskTemp(taskID);
        currentTaskDetailScriptableRef = GetCurrentTaskScriptableRef(taskID);

        if (currentTaskDetails.IsCompleted) return;
        IncrementTaskTriggeredValue(taskID);
    }
    void IncrementTaskTriggeredValue(String taskID)
    {
        if (currentTaskDetailScriptableRef.TaskTriggered < currentTaskDetailScriptableRef.TaskTargetValue)
        {
            currentTaskDetails.TaskTriggered++;
            currentTaskDetailScriptableRef.TaskTriggered = currentTaskDetails.TaskTriggered;
        }
        OnTaskUpdateEvent?.Invoke(taskID);
        if (currentTaskDetailScriptableRef.TaskTriggered >= currentTaskDetailScriptableRef.TaskTargetValue)
        {
            if (currentTaskDetailScriptableRef.IsCompleted) return;

            currentTaskDetails.IsCompleted = true;
            currentTaskDetailScriptableRef.IsCompleted = true;
            taskCompletedValue++;
            CheckForAllTasks();
            string instructions = $"<color=yellow> Task:</color> {currentTaskDetails.TaskTagHeading} <color=green> Completed</color>";
            InstructionsPopupManager.Instance.ShowInstructions(instructions);
        }
    }
    void CheckForAllTasks()
    {
        if (!levelCompleted && (taskCompletedValue >= taskDetails.Length))
        {
            levelCompleted = true;
            OnAllTaskCompleted?.Invoke();
            Invoke(nameof(ResetTasks), 3f);
        }
    }
    void ResetTasks()
    {
        foreach (var task in taskFile.tasks)
        {
            task.TaskTriggered = 0;
            task.IsCompleted = false;
        }
    }
}